<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Enums\UserType;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\RateLimiter;

/**
 * RateLimitingTest - Phase 7.5 Task 1
 * 
 * Tests role-based rate limiting implementation:
 * - Tenant: 60 requests/minute
 * - Landlord: 120 requests/minute
 * - Admin: 300 requests/minute
 * - Public: 30 requests/minute
 */
class RateLimitingTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        
        // Clear rate limiter before each test
        RateLimiter::clear('api:rate-limit:tenant:*');
        RateLimiter::clear('api:rate-limit:landlord:*');
        RateLimiter::clear('api:rate-limit:admin:*');
        RateLimiter::clear('api:rate-limit:public:*');
    }

    /**
     * Test that tenant rate limit is enforced (60 req/min)
     */
    public function test_tenant_rate_limit_enforced(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $tenant->createToken('test')->plainTextToken;

        // Make 60 requests (should succeed)
        for ($i = 0; $i < 60; $i++) {
            $response = $this->withHeaders([
                'Authorization' => "Bearer {$token}",
            ])->getJson('/api/tenant/dashboard');
            
            $response->assertStatus(200);
            $response->assertHeader('X-RateLimit-Limit', '60');
        }

        // 61st request should be rate limited
        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/tenant/dashboard');

        $response->assertStatus(429);
        $response->assertJsonStructure([
            'message',
            'retry_after',
        ]);
        $response->assertHeader('Retry-After');
        $response->assertHeader('X-RateLimit-Limit', '60');
        $response->assertHeader('X-RateLimit-Remaining', '0');
    }

    /**
     * Test that landlord rate limit is enforced (120 req/min)
     */
    public function test_landlord_rate_limit_enforced(): void
    {
        $landlord = User::factory()->create(['user_type' => UserType::LANDLORD]);
        $token = $landlord->createToken('test')->plainTextToken;

        // Make 120 requests (should succeed)
        for ($i = 0; $i < 120; $i++) {
            $response = $this->withHeaders([
                'Authorization' => "Bearer {$token}",
            ])->getJson('/api/landlord/onboarding');
            
            $response->assertStatus(200);
            $response->assertHeader('X-RateLimit-Limit', '120');
        }

        // 121st request should be rate limited
        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/landlord/onboarding');

        $response->assertStatus(429);
        $response->assertJsonStructure([
            'message',
            'retry_after',
        ]);
        $response->assertHeader('X-RateLimit-Limit', '120');
        $response->assertHeader('X-RateLimit-Remaining', '0');
    }

    /**
     * Test that admin has higher rate limit (300 req/min)
     * 
     * Note: Only testing first 50 requests for performance
     */
    public function test_admin_has_higher_rate_limit(): void
    {
        $admin = User::factory()->create(['user_type' => UserType::ADMIN]);
        $token = $admin->createToken('test')->plainTextToken;

        // Make 50 requests (should all succeed with limit 300)
        for ($i = 0; $i < 50; $i++) {
            $response = $this->withHeaders([
                'Authorization' => "Bearer {$token}",
            ])->getJson('/api/admin/dashboard');
            
            $response->assertStatus(200);
            $response->assertHeader('X-RateLimit-Limit', '300');
        }

        // Verify remaining count is correct
        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/admin/dashboard');

        $remaining = $response->headers->get('X-RateLimit-Remaining');
        $this->assertGreaterThan(240, (int)$remaining); // Should have 249 remaining
    }

    /**
     * Test that public/unauthenticated requests have low rate limit (30 req/min)
     */
    public function test_public_rate_limit_enforced(): void
    {
        // Make 30 requests (should succeed)
        for ($i = 0; $i < 30; $i++) {
            $response = $this->getJson('/api/listings');
            
            $response->assertStatus(200);
            $response->assertHeader('X-RateLimit-Limit', '30');
        }

        // 31st request should be rate limited
        $response = $this->getJson('/api/listings');

        $response->assertStatus(429);
        $response->assertJsonStructure([
            'message',
            'retry_after',
        ]);
        $response->assertHeader('X-RateLimit-Limit', '30');
        $response->assertHeader('X-RateLimit-Remaining', '0');
    }

    /**
     * Test rate limit headers are present on all responses
     */
    public function test_rate_limit_headers_present(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $tenant->createToken('test')->plainTextToken;

        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/tenant/dashboard');

        $response->assertStatus(200);
        $response->assertHeader('X-RateLimit-Limit');
        $response->assertHeader('X-RateLimit-Remaining');
        
        $limit = $response->headers->get('X-RateLimit-Limit');
        $remaining = $response->headers->get('X-RateLimit-Remaining');
        
        $this->assertEquals('60', $limit);
        $this->assertEquals('59', $remaining); // First request
    }

    /**
     * Test that different roles have different rate limits
     */
    public function test_different_roles_have_different_limits(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $landlord = User::factory()->create(['user_type' => UserType::LANDLORD]);
        $admin = User::factory()->create(['user_type' => UserType::ADMIN]);

        $tenantToken = $tenant->createToken('test')->plainTextToken;
        $landlordToken = $landlord->createToken('test')->plainTextToken;
        $adminToken = $admin->createToken('test')->plainTextToken;

        // Check tenant limit
        $response = $this->withHeaders(['Authorization' => "Bearer {$tenantToken}"])
            ->getJson('/api/tenant/dashboard');
        $this->assertEquals('60', $response->headers->get('X-RateLimit-Limit'));

        // Check landlord limit
        $response = $this->withHeaders(['Authorization' => "Bearer {$landlordToken}"])
            ->getJson('/api/landlord/onboarding');
        $this->assertEquals('120', $response->headers->get('X-RateLimit-Limit'));

        // Check admin limit
        $response = $this->withHeaders(['Authorization' => "Bearer {$adminToken}"])
            ->getJson('/api/admin/dashboard');
        $this->assertEquals('300', $response->headers->get('X-RateLimit-Limit'));
    }

    /**
     * Test that rate limit is per-user (different users don't share limits)
     */
    public function test_rate_limit_is_per_user(): void
    {
        $tenant1 = User::factory()->create(['user_type' => UserType::TENANT]);
        $tenant2 = User::factory()->create(['user_type' => UserType::TENANT]);
        
        $token1 = $tenant1->createToken('test')->plainTextToken;
        $token2 = $tenant2->createToken('test')->plainTextToken;

        // Make 60 requests with first tenant
        for ($i = 0; $i < 60; $i++) {
            $response = $this->withHeaders(['Authorization' => "Bearer {$token1}"])
                ->getJson('/api/tenant/dashboard');
            $response->assertStatus(200);
        }

        // First tenant should be rate limited
        $response = $this->withHeaders(['Authorization' => "Bearer {$token1}"])
            ->getJson('/api/tenant/dashboard');
        $response->assertStatus(429);

        // Second tenant should still have full quota
        $response = $this->withHeaders(['Authorization' => "Bearer {$token2}"])
            ->getJson('/api/tenant/dashboard');
        $response->assertStatus(200);
        $this->assertEquals('59', $response->headers->get('X-RateLimit-Remaining'));
    }

    /**
     * Test that 429 response includes helpful message
     */
    public function test_429_response_includes_helpful_message(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $tenant->createToken('test')->plainTextToken;

        // Exhaust rate limit
        for ($i = 0; $i < 60; $i++) {
            $this->withHeaders(['Authorization' => "Bearer {$token}"])
                ->getJson('/api/tenant/dashboard');
        }

        // Get rate limited response
        $response = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->getJson('/api/tenant/dashboard');

        $response->assertStatus(429);
        $response->assertJson([
            'message' => 'Too many requests. Please try again later.',
        ]);
        $response->assertJsonStructure([
            'message',
            'retry_after',
        ]);
    }

    /**
     * Test that webhook endpoint is NOT rate limited
     * (Important: webhooks should always be accepted)
     */
    public function test_webhook_endpoint_not_rate_limited(): void
    {
        // Make 100 webhook requests (more than any rate limit)
        for ($i = 0; $i < 100; $i++) {
            $response = $this->postJson('/api/webhooks/stripe', [
                'type' => 'test.event',
            ]);
            
            // Should not be rate limited (will fail auth/validation instead)
            // The key point is NO 429 status
            $this->assertNotEquals(429, $response->status());
        }
    }
}
