<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Enums\UserType;
use App\Services\MetricsService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Cache;

/**
 * MetricsTest - Phase 7.5 Task 2
 * 
 * Tests observability and metrics implementation:
 * - Request tracking
 * - Latency measurement
 * - Error rate tracking
 * - Queue depth monitoring
 */
class MetricsTest extends TestCase
{
    use RefreshDatabase;

    protected MetricsService $metricsService;

    protected function setUp(): void
    {
        parent::setUp();
        
        $this->metricsService = app(MetricsService::class);
        $this->metricsService->reset(); // Clear metrics before each test
    }

    /**
     * Test that metrics are recorded for API requests
     */
    public function test_metrics_recorded_for_api_requests(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $tenant->createToken('test')->plainTextToken;

        // Make an API request
        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/tenant/dashboard');

        $response->assertStatus(200);

        // Check that metrics were recorded
        $summary = $this->metricsService->getSummary();
        
        $this->assertGreaterThan(0, $summary['requests']['total']);
        $this->assertEquals(1, $summary['requests']['rate']['current_minute']);
        $this->assertArrayHasKey('latency', $summary);
        $this->assertEquals(1, $summary['latency']['count']);
    }

    /**
     * Test latency percentiles calculation
     */
    public function test_latency_percentiles_calculated(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $tenant->createToken('test')->plainTextToken;

        // Make multiple requests to generate latency data
        for ($i = 0; $i < 10; $i++) {
            $this->withHeaders([
                'Authorization' => "Bearer {$token}",
            ])->getJson('/api/tenant/dashboard');
        }

        $latency = $this->metricsService->getLatencyPercentiles();

        $this->assertArrayHasKey('p50', $latency);
        $this->assertArrayHasKey('p95', $latency);
        $this->assertArrayHasKey('p99', $latency);
        $this->assertArrayHasKey('avg', $latency);
        $this->assertArrayHasKey('min', $latency);
        $this->assertArrayHasKey('max', $latency);
        $this->assertEquals(10, $latency['count']);
        
        // Verify percentiles are numbers
        $this->assertIsFloat($latency['p50']);
        $this->assertIsFloat($latency['p95']);
        $this->assertIsFloat($latency['p99']);
    }

    /**
     * Test error rate tracking
     */
    public function test_error_rate_tracked(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $tenant->createToken('test')->plainTextToken;

        // Make successful requests
        for ($i = 0; $i < 5; $i++) {
            $this->withHeaders([
                'Authorization' => "Bearer {$token}",
            ])->getJson('/api/tenant/dashboard');
        }

        // Make requests that will fail (404)
        for ($i = 0; $i < 2; $i++) {
            $this->withHeaders([
                'Authorization' => "Bearer {$token}",
            ])->getJson('/api/tenant/nonexistent');
        }

        $errors = $this->metricsService->getErrorRate();

        $this->assertGreaterThan(0, $errors['4xx_count']);
        $this->assertEquals(0, $errors['5xx_count']); // No 5xx errors
        $this->assertGreaterThan(0, $errors['error_rate']);
    }

    /**
     * Test request rate tracking
     */
    public function test_request_rate_tracked(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $tenant->createToken('test')->plainTextToken;

        // Make 5 requests
        for ($i = 0; $i < 5; $i++) {
            $this->withHeaders([
                'Authorization' => "Bearer {$token}",
            ])->getJson('/api/tenant/dashboard');
        }

        $rate = $this->metricsService->getRequestRate();

        $this->assertArrayHasKey('current_minute', $rate);
        $this->assertArrayHasKey('avg_per_minute', $rate);
        $this->assertEquals(5, $rate['current_minute']);
        $this->assertGreaterThan(0, $rate['avg_per_minute']);
    }

    /**
     * Test metrics by role tracking
     */
    public function test_metrics_tracked_by_role(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $landlord = User::factory()->create(['user_type' => UserType::LANDLORD]);
        $admin = User::factory()->create(['user_type' => UserType::ADMIN]);

        $tenantToken = $tenant->createToken('test')->plainTextToken;
        $landlordToken = $landlord->createToken('test')->plainTextToken;
        $adminToken = $admin->createToken('test')->plainTextToken;

        // Make requests as different roles
        $this->withHeaders(['Authorization' => "Bearer {$tenantToken}"])
            ->getJson('/api/tenant/dashboard');
        
        $this->withHeaders(['Authorization' => "Bearer {$landlordToken}"])
            ->getJson('/api/landlord/onboarding');
        
        $this->withHeaders(['Authorization' => "Bearer {$adminToken}"])
            ->getJson('/api/admin/dashboard');

        $summary = $this->metricsService->getSummary();

        $this->assertEquals(1, $summary['by_role']['tenant']);
        $this->assertEquals(1, $summary['by_role']['landlord']);
        $this->assertEquals(1, $summary['by_role']['admin']);
    }

    /**
     * Test recent requests tracking
     */
    public function test_recent_requests_tracked(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $tenant->createToken('test')->plainTextToken;

        // Make a few requests
        for ($i = 0; $i < 3; $i++) {
            $this->withHeaders([
                'Authorization' => "Bearer {$token}",
            ])->getJson('/api/tenant/dashboard');
        }

        $recent = $this->metricsService->getRecentRequests(10);

        $this->assertCount(3, $recent);
        
        foreach ($recent as $request) {
            $this->assertArrayHasKey('timestamp', $request);
            $this->assertArrayHasKey('method', $request);
            $this->assertArrayHasKey('path', $request);
            $this->assertArrayHasKey('status', $request);
            $this->assertArrayHasKey('duration', $request);
            $this->assertArrayHasKey('user_id', $request);
            $this->assertArrayHasKey('user_type', $request);
        }
    }

    /**
     * Test admin can access metrics endpoint
     */
    public function test_admin_can_access_metrics_endpoint(): void
    {
        $admin = User::factory()->create(['user_type' => UserType::ADMIN]);
        $token = $admin->createToken('test')->plainTextToken;

        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/admin/metrics');

        $response->assertStatus(200);
        $response->assertJsonStructure([
            'success',
            'data' => [
                'timestamp',
                'requests',
                'latency',
                'errors',
                'queue',
                'by_role',
            ],
        ]);
    }

    /**
     * Test non-admin cannot access metrics endpoint
     */
    public function test_non_admin_cannot_access_metrics(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $tenant->createToken('test')->plainTextToken;

        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/admin/metrics');

        $response->assertStatus(403);
    }

    /**
     * Test latency endpoint
     */
    public function test_latency_endpoint_returns_data(): void
    {
        $admin = User::factory()->create(['user_type' => UserType::ADMIN]);
        $token = $admin->createToken('test')->plainTextToken;

        // Generate some traffic
        for ($i = 0; $i < 5; $i++) {
            $this->withHeaders(['Authorization' => "Bearer {$token}"])
                ->getJson('/api/admin/dashboard');
        }

        $response = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->getJson('/api/admin/metrics/latency');

        $response->assertStatus(200);
        $response->assertJsonStructure([
            'success',
            'data' => [
                'p50',
                'p95',
                'p99',
                'avg',
                'min',
                'max',
                'count',
            ],
        ]);
    }

    /**
     * Test errors endpoint
     */
    public function test_errors_endpoint_returns_data(): void
    {
        $admin = User::factory()->create(['user_type' => UserType::ADMIN]);
        $token = $admin->createToken('test')->plainTextToken;

        $response = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->getJson('/api/admin/metrics/errors?minutes=5');

        $response->assertStatus(200);
        $response->assertJsonStructure([
            'success',
            'data' => [
                '4xx_count',
                '5xx_count',
                'total_errors',
                'total_requests',
                'error_rate',
            ],
        ]);
    }

    /**
     * Test queue endpoint
     */
    public function test_queue_endpoint_returns_data(): void
    {
        $admin = User::factory()->create(['user_type' => UserType::ADMIN]);
        $token = $admin->createToken('test')->plainTextToken;

        $response = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->getJson('/api/admin/metrics/queue');

        $response->assertStatus(200);
        $response->assertJsonStructure([
            'success',
            'data' => [
                'pending',
                'failed',
                'total',
            ],
        ]);
    }

    /**
     * Test requests endpoint
     */
    public function test_requests_endpoint_returns_data(): void
    {
        $admin = User::factory()->create(['user_type' => UserType::ADMIN]);
        $token = $admin->createToken('test')->plainTextToken;

        $response = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->getJson('/api/admin/metrics/requests?minutes=5');

        $response->assertStatus(200);
        $response->assertJsonStructure([
            'success',
            'data' => [
                'current_minute',
                'last_5_minutes',
                'total_last_5_minutes',
                'avg_per_minute',
            ],
        ]);
    }

    /**
     * Test recent requests endpoint
     */
    public function test_recent_requests_endpoint_returns_data(): void
    {
        $admin = User::factory()->create(['user_type' => UserType::ADMIN]);
        $token = $admin->createToken('test')->plainTextToken;

        // Generate some traffic
        for ($i = 0; $i < 3; $i++) {
            $this->withHeaders(['Authorization' => "Bearer {$token}"])
                ->getJson('/api/admin/dashboard');
        }

        $response = $this->withHeaders(['Authorization' => "Bearer {$token}"])
            ->getJson('/api/admin/metrics/recent?limit=10');

        $response->assertStatus(200);
        $response->assertJsonStructure([
            'success',
            'data',
        ]);
        
        $this->assertIsArray($response->json('data'));
    }
}
