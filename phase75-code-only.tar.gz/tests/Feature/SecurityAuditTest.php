<?php

namespace Tests\Feature;

use Tests\TestCase;
use App\Models\User;
use App\Enums\UserType;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;

/**
 * SecurityAuditTest - Phase 7.5 Task 4
 * 
 * Comprehensive security verification:
 * - Authentication enforcement
 * - Role isolation
 * - Authorization checks
 * - Token validation
 * - Attack prevention
 */
class SecurityAuditTest extends TestCase
{
    use RefreshDatabase;

    /**
     * Test that all API routes require authentication
     */
    public function test_all_routes_require_authentication(): void
    {
        $protectedRoutes = [
            '/api/tenant/dashboard',
            '/api/landlord/onboarding',
            '/api/admin/dashboard',
        ];

        foreach ($protectedRoutes as $route) {
            $response = $this->getJson($route);
            $this->assertContains($response->status(), [401, 403], 
                "Route {$route} did not require authentication");
        }
    }

    /**
     * Test that tenants cannot access landlord routes
     */
    public function test_tenant_cannot_access_landlord_routes(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $tenant->createToken('test')->plainTextToken;

        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/landlord/onboarding');

        $response->assertStatus(403);
        $response->assertJson([
            'message' => 'This action is only available to landlords.',
        ]);
    }

    /**
     * Test that landlords cannot access tenant routes
     */
    public function test_landlord_cannot_access_tenant_routes(): void
    {
        $landlord = User::factory()->create(['user_type' => UserType::LANDLORD]);
        $token = $landlord->createToken('test')->plainTextToken;

        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/tenant/dashboard');

        $response->assertStatus(403);
        $response->assertJson([
            'message' => 'This action is only available to tenants.',
        ]);
    }

    /**
     * Test that non-admins cannot access admin routes
     */
    public function test_tenant_cannot_access_admin_routes(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $tenant->createToken('test')->plainTextToken;

        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/admin/dashboard');

        $response->assertStatus(403);
    }

    /**
     * Test that missing authentication returns 401
     */
    public function test_unauthorized_returns_401(): void
    {
        $response = $this->getJson('/api/tenant/dashboard');
        $response->assertStatus(401);
    }

    /**
     * Test that wrong role returns 403
     */
    public function test_forbidden_returns_403(): void
    {
        $tenant = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $tenant->createToken('test')->plainTextToken;

        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/landlord/properties');

        $response->assertStatus(403);
    }

    /**
     * Test that expired tokens are rejected
     */
    public function test_expired_token_rejected(): void
    {
        $user = User::factory()->create(['user_type' => UserType::TENANT]);
        $token = $user->createToken('test')->plainTextToken;

        // Manually expire the token
        $user->tokens()->update(['created_at' => now()->subYear()]);

        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/tenant/dashboard');

        // Should be rejected (exact behavior depends on Sanctum config)
        $this->assertContains($response->status(), [401, 403]);
    }

    /**
     * Test that invalid tokens are rejected
     */
    public function test_invalid_token_rejected(): void
    {
        $response = $this->withHeaders([
            'Authorization' => 'Bearer invalid-token-12345',
        ])->getJson('/api/tenant/dashboard');

        $response->assertStatus(401);
    }

    /**
     * Test that CSRF protection is enabled for web routes
     */
    public function test_csrf_protection_enabled(): void
    {
        // CSRF protection is enabled by default in Laravel
        // API routes use token-based auth, not CSRF tokens
        // This test verifies the configuration
        
        $csrfEnabled = config('sanctum.stateful');
        $this->assertIsArray($csrfEnabled);
    }

    /**
     * Test that SQL injection is prevented
     */
    public function test_sql_injection_prevented(): void
    {
        $user = User::factory()->create(['user_type' => UserType::ADMIN]);
        $token = $user->createToken('test')->plainTextToken;

        // Attempt SQL injection in query parameter
        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/admin/audit-logs?user_id=1 OR 1=1');

        // Should not cause SQL error (Eloquent prevents injection)
        $this->assertNotEquals(500, $response->status());
    }

    /**
     * Test that XSS is prevented in responses
     */
    public function test_xss_prevented(): void
    {
        $user = User::factory()->create([
            'user_type' => UserType::TENANT,
            'name' => '<script>alert("xss")</script>',
        ]);
        $token = $user->createToken('test')->plainTextToken;

        $response = $this->withHeaders([
            'Authorization' => "Bearer {$token}",
        ])->getJson('/api/tenant/dashboard');

        // Response should escape HTML
        $content = $response->getContent();
        $this->assertStringNotContainsString('<script>', $content);
    }

    /**
     * Test that passwords are hashed
     */
    public function test_password_hashing_secure(): void
    {
        $user = User::factory()->create([
            'password' => Hash::make('password123'),
        ]);

        // Password should be hashed, not plain text
        $this->assertNotEquals('password123', $user->password);
        $this->assertTrue(Hash::check('password123', $user->password));
        
        // Hash should be bcrypt
        $this->assertStringStartsWith('$2y$', $user->password);
    }
}
